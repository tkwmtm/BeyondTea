# [BDHelper](https://t.me/BDHelperBot)

[![Bot API](http://img.shields.io/badge/Bot%20API-v3.0.0-00aced.svg)](https://core.telegram.org/bots/api)
[![https://t.me/BeyondTeam](https://img.shields.io/badge/💬%20Telegram-BeyondTeam-00aced.svg)](https://t.me/BeyondTeam)

## Beyond Helper V1.5
An Helper Bot For BDReborn Based On BDMessenger

* * *

## Configure

* Put Your Bot `TOKEN` At Line `3`
* Put Your `Telegram ID` At Line `5`
* Put Your `Telegram ID` And Your Cli Bot `Telegram ID` At Line `165`

# Installation

```sh
# Let's install the bot.
cd $HOME
git clone https://github.com/BeyondTeam/BDHelper.git
cd BDHelper
chmod +x beyond.sh
./beyond.sh install
./beyond.sh 


# For Auto Launch:
cd BDHelper
chmod 777 autobd.sh
tmux
./autobd.sh
# End ;)
```
### One command
To install everything in one command, use:
```sh
cd $HOME && git clone https://github.com/BeyondTeam/BDHelper.git && cd BDHelper && chmod +x beyond.sh && ./beyond.sh install && ./beyond.sh
```

# Support and Development

More information [Beyond Global Chat](https://telegram.me/joinchat/AAAAAEIDQ8HTjezV4syUSA)

# Special thanks to

[@AmirBagheri](https://github.com/CodeLua)
* * *

# Developers!

[SoLiD](https://github.com/solid021) ([Telegram](https://t.me/SoLiD))

[ToOfan](https://github.com/To0fan) ([Telegram](https://t.me/ToOfan))

### Our Telegram channel:

[@dwzhS6V7](https://t.me/
thdwzhS6V7)
